import "./Home.css"

export const Home=() => {
    return (
        
        <div className="">
            <h1>Delicious Food</h1>

            <div className="kfc">
                <h1>LET'S ORDER FOR DELIVERY  OR DINE-IN</h1>
                
                <img src="https://images.ctfassets.net/wtodlh47qxpt/bwwtSv4zmZZm42c5wSg8Z/bd28ca73bbefa15b45f14c994e72ed03/Matchday_Banner_1440x396px.jpg?w=1536&fit=fill&fm=webp"
               />
            </div>

            <div className="website">
              <h1>WELCOME !</h1>  
            </div>
            <h1>BROWSE CATEGORIES FROM KFC</h1>
            <div className="box">
                <div className="card">
               
         <img src="https://orderserv-kfc-assets.yum.com/15895bb59f7b4bb588ee933f8cd5344a/images/items/xl/A-33781-0.jpg?ver=14.89"/>      
                <img src="https://orderserv-kfc-assets.yum.com/15895bb59f7b4bb588ee933f8cd5344a/images/categories/CAT3131.jpg?ver=14.89"/>
               
               <img src="https://orderserv-kfc-assets.yum.com/15895bb59f7b4bb588ee933f8cd5344a/images/categories/CAT3132.jpg?ver=14.89"/>
               <img src="https://orderserv-kfc-assets.yum.com/15895bb59f7b4bb588ee933f8cd5344a/images/items/xl/A-32775-0.jpg?ver=14.89"/>
              <br />
               
                </div>
            </div>


            <h1>BROWSE CATEGORIES FROM GRILL-IN</h1>
            <div className="box">
                <div className="card">
               
         <img src="https://grillinn.in/wp-content/uploads/2022/03/10.jpg"/>      
                <img src="https://grillinn.in/wp-content/uploads/2022/03/8-1.jpg"/>
               
               <img src="https://grillinn.in/wp-content/uploads/2022/03/7.jpg"/>
               <img src="https://grillinn.in/wp-content/uploads/2022/03/9.jpg"/>
              <br />
               
                </div>
            </div>


      <h1>ONLY GRILL-INN</h1>
            <div ><img className="grill" src="https://grillinn.in/wp-content/uploads/2022/04/WhatsApp-Image-2022-04-07-at-7.48.04-PM.jpeg"/></div>
      
      
        </div>
        
    )
}