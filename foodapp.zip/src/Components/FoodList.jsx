

import { useContext, useEffect } from "react";
import { useState } from "react";
import { Link } from "react-router-dom";
import "./Foor.css"


export const Foodlist=() => {

const [food,setFood] =useState([
 
])
const [data,setdata]= useState([])
// const [seven,setSeven] = useState([{}])
// const [nine,setNine] = useState([{}])
// const [kfc,setKfc] = useState([{}])
// const [page,setpage] = useState(1)
// const [text, setText] = useState("");
// const [rat,setrat] = useState(0)
// const [rats,setrats] = useState(0)
// const [q, setQ] = useState("");


async function getData() {
    const data=await fetch("https://food-albert.herokuapp.com/food").then(d=> d.json())
    setFood(data)
     setdata(data)
     
}
   useEffect(() => {
       getData()
   },[])



  //ADD to cart
 const handleFilter=(e)=> {
    let  Element=[...data]
    
   Element= Element.filter(item=> (
      
      item.restaurant===e
      
    ))
    setFood(Element)
    // console.log(Element)
  }
  
//sorting
function onSelectionChange(e) {
  const sortDirection = e.target.value;

  const copyArray = [...food]; // create a new array & not mutate state


  copyArray.sort((a, b) => {
      //   return sortDirection === "0" ? a.price - b.price : b.price - a.price;
      if (sortDirection === "0") {
          return a.price - b.price
      }
      else if (sortDirection === "1") {
          return b.price - a.price
      }

      else if (sortDirection === "2") {
          return a.ratings - b.ratings
      }

      else if (sortDirection === "3") {
          return b.ratings - a.ratings
      }

  });
  setFood(copyArray); //re-render

}
  //  console.log(food)
   return (
     <div>
       <div className="i">
       <img src="https://grillinn.in/wp-content/themes/grill_inn/img/GrillInn-Logo.png"/>
       <img src="https://online.kfc.co.in/static/media/kfcLogo.492728c6.svg"/>

       <img src="https://www.mcdonalds.com/content/dam/sites/usa/nfl/icons/arches-logo_108x108.jpg"/>
       </div>
    <h1>LET'S ORDER</h1>
     
        <div className="sort">
        <h1>SORTING</h1>
            <select  defaultValue={0} onChange={onSelectionChange}>
                <option className="select" value={0}>Ascending-Price</option>
                <option className="select" value={1}>Descending-price</option>
                <option className="select" value={2} >Ratings-Ascending</option>
                <option className="select" value={3} >Ratings-Descending</option>
            </select>
            </div>
            <br></br>
               
              <div className="filter">
              <h1>FILTERING</h1>
            <button style={{width:"200px"}} onClick={() => handleFilter("KFC")}>KFC</button>
             
            <button style={{width:"200px"}} onClick={() => handleFilter("Grill-in")}>Grill-in</button>
            
            <button style={{width:"200px"}} onClick={() => handleFilter("MacDonald")}>Macdonald</button>
            </div>
      
    <div className="list_container"  
      
     
       
  >
      {/* On clicking this card anywhere, user goes to user details */}


     {food.map((e) => {
    
       return (
       <>

       <div className="food_card" key={e._id}>
        <Link to = {`/foodlist/${e._id}`}>
          
      
    <div>    <img className="food_image"  src={e.image} /></div>
    <div>    <span className="employee_name">  {e.food_name} 
       </span></div>
     <div>   <span className="employee_title">${e.price}</span> </div>
     <div>   <span className="employee_title">${e.id}</span> </div>
     <div>   <span className="employee_title">${e.restaurant}</span> </div>
     <div>   <span className="employee_title">${e.ratings}</span> </div>
     </Link>
     {/* <button onClick={() => {
       
        handlefetch(food)
      }}>ADD TO CART</button> */}

     
      </div>
      
     
     
     </>

)

})}

    </div>
    </div>
  );

}